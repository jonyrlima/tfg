#define _STLP_PLATFORM "Cygwin"

/* Glibc is the platform API */
#if !defined (_STLP_USE_GLIBC)
#  define _STLP_USE_GLIBC
#endif
